import React, { Component } from 'react';
import AmountOfNewCreditChart from './amount_of_new_credit_chart';

export default class AmountOfNewCredit extends Component {
    render(){
        return(
            <div>
                <AmountOfNewCreditChart />
            </div>
        );
    }
}