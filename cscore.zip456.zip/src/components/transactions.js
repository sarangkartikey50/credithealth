import React, { Component } from 'react';
import Timeline from './timeline';

export default class Transactions extends Component {
    render(){
        return(
            <div>
                <div>
                    <Timeline />
                </div>
            </div>
        );
    }
}